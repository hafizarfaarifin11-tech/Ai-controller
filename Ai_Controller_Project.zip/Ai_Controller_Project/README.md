# AI Controller v0.1.0

A small Android floating assistant that captures the screen only after Android's screen-capture consent and performs bundled on-device OCR using Google ML Kit Text Recognition.

## What this build does

- Floating AI bubble that can be moved over other apps.
- Explicit user-triggered screen analysis (no continuous scanning).
- Offline OCR for Latin text visible on screen.
- Small local rule-based hints based on recognized words.
- No API key, no app internet permission, and no screenshot upload.

## Honest v0.1 limitations

This is not a general-purpose local language model or full game-vision model. It reads text and applies a few local rules. It does not reliably detect enemies, characters, weapons, health bars, map positions, or the meaning of a complete game scene. OCR accuracy depends on text size, contrast, motion, and whether the game allows screen capture. Protected/secure content may appear blank.

## Build with GitHub Actions

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Ensure `android.yml` is placed at `.github/workflows/android.yml` (the workflow is already included there).
4. Push to `main` or `master`, or run **Android CI** from the Actions tab.
5. Download the `Ai-Controller-debug-apk` artifact from the completed workflow.

The workflow uses Java 17, Gradle 8.13, Android SDK 36, and builds `app-debug.apk`.

## First run

1. Install the debug APK.
2. Open AI Controller.
3. Grant **Display over other apps** permission.
4. Tap **Mulai AI Assistant** and approve Android's screen-capture prompt.
5. Open the floating AI bubble and tap **Analyze Screen**.
6. Close the assistant from the app or the foreground notification.

The bundled ML Kit text-recognition model is packaged with the app, so OCR does not need a first-run model download. Gradle downloads dependencies during the GitHub build, but the installed app does not need network access for OCR.
