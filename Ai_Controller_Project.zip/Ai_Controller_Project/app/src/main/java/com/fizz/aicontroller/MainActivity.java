package com.fizz.aicontroller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 4101;

    private MediaProjectionManager projectionManager;
    private TextView permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF0B1016);
        getWindow().setNavigationBarColor(0xFF0B1016);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionStatus();
    }

    private void buildScreen() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(0xFF0B1016);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(28), dp(22), dp(28));
        scrollView.addView(content);

        TextView eyebrow = text("OFFLINE GAME ASSISTANT", 11, 0xFF36D6B0, true);
        eyebrow.setLetterSpacing(0.12f);
        content.addView(eyebrow);

        TextView title = text("AI Controller", 31, 0xFFFFFFFF, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(8);
        content.addView(title, titleParams);

        TextView subtitle = text(
                "Asisten layar ringan yang membaca teks HUD langsung di perangkat. Tanpa akun, API key, atau koneksi internet saat analisis.",
                15, 0xFFB7C2CC, false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(8);
        content.addView(subtitle, subtitleParams);

        LinearLayout infoCard = card();
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = dp(24);
        content.addView(infoCard, cardParams);

        TextView infoTitle = text("Yang tersedia di v0.1", 17, 0xFFFFFFFF, true);
        infoCard.addView(infoTitle);
        addCardLine(infoCard, "• Floating overlay yang bisa dipindahkan");
        addCardLine(infoCard, "• Screenshot layar dengan izin Android");
        addCardLine(infoCard, "• OCR offline untuk membaca teks HUD");
        addCardLine(infoCard, "• Saran sederhana berdasarkan teks yang terbaca");

        LinearLayout noteCard = card();
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(12);
        content.addView(noteCard, noteParams);
        TextView noteTitle = text("Batas kemampuan", 16, 0xFFFFD28A, true);
        noteCard.addView(noteTitle);
        TextView note = text(
                "Versi ini belum mengenali musuh, senjata, posisi, atau isi minimap seperti AI vision penuh. Hasil OCR bisa salah jika teks kecil, buram, atau tertutup overlay.",
                13, 0xFFD0D6DC, false);
        LinearLayout.LayoutParams noteTextParams = new LinearLayout.LayoutParams(-1, -2);
        noteTextParams.topMargin = dp(7);
        noteCard.addView(note, noteTextParams);

        permissionStatus = text("Memeriksa izin...", 13, 0xFFB7C2CC, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(22);
        content.addView(permissionStatus, statusParams);

        Button overlayButton = makeButton("1. AKTIFKAN IZIN OVERLAY");
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(54));
        buttonParams.topMargin = dp(10);
        content.addView(overlayButton, buttonParams);
        overlayButton.setOnClickListener(v -> requestOverlayPermission());

        Button startButton = makeButton("2. MULAI AI ASSISTANT");
        LinearLayout.LayoutParams startParams = new LinearLayout.LayoutParams(-1, dp(54));
        startParams.topMargin = dp(10);
        content.addView(startButton, startParams);
        startButton.setOnClickListener(v -> beginScreenCapture());

        Button stopButton = makeButton("HENTIKAN ASSISTANT");
        stopButton.setBackground(roundBackground(0xFF26313D, dp(14)));
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(-1, dp(50));
        stopParams.topMargin = dp(10);
        content.addView(stopButton, stopParams);
        stopButton.setOnClickListener(v -> {
            stopService(new Intent(this, AIOverlayService.class));
            Toast.makeText(this, "AI Controller dihentikan", Toast.LENGTH_SHORT).show();
        });

        TextView footer = text("AI Controller v0.1.0  •  Local OCR  •  No API Key", 11, 0xFF71808F, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams = new LinearLayout.LayoutParams(-1, -2);
        footerParams.topMargin = dp(22);
        content.addView(footer, footerParams);

        setContentView(scrollView);
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show();
        }
    }

    private void beginScreenCapture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin overlay terlebih dahulu", Toast.LENGTH_LONG).show();
            requestOverlayPermission();
            return;
        }
        if (projectionManager == null) {
            Toast.makeText(this, "Screen capture tidak tersedia di perangkat ini", Toast.LENGTH_LONG).show();
            return;
        }
        // Android will show its own consent dialog before screen content can be captured.
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, AIOverlayService.class);
                serviceIntent.putExtra(AIOverlayService.EXTRA_RESULT_CODE, resultCode);
                serviceIntent.putExtra(AIOverlayService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                Toast.makeText(this, "AI Controller aktif. Buka bubble AI di layar.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Izin screen capture tidak diberikan", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void refreshPermissionStatus() {
        if (permissionStatus == null) return;
        boolean allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        permissionStatus.setText(allowed
                ? "Status izin: overlay sudah diizinkan."
                : "Status izin: overlay belum diizinkan.");
        permissionStatus.setTextColor(allowed ? 0xFF36D6B0 : 0xFFFFC078);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(roundBackground(0xFF151D27, dp(18)));
        return box;
    }

    private void addCardLine(LinearLayout card, String value) {
        TextView line = text(value, 13, 0xFFD0D6DC, false);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(9);
        card.addView(line, params);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        view.setLineSpacing(dp(3), 1.0f);
        return view;
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(13);
        button.setTextColor(0xFF07120F);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackground(roundBackground(0xFF36D6B0, dp(14)));
        return button;
    }

    private android.graphics.drawable.GradientDrawable roundBackground(int color, int radius) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
