package com.fizz.aicontroller;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class AIOverlayService extends Service {
    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";

    private static final String CHANNEL_ID = "ai_controller_capture";
    private static final int NOTIFICATION_ID = 7301;
    private static final String ACTION_STOP = "com.fizz.aicontroller.STOP";
    private static final int MAX_OCR_CHARS = 520;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean pendingAnalysis = new AtomicBoolean(false);
    private final AtomicBoolean analysisInProgress = new AtomicBoolean(false);

    private WindowManager windowManager;
    private WindowManager.LayoutParams overlayParams;
    private View currentOverlay;
    private TextView statusView;
    private TextView resultView;
    private TextView analyzeButton;
    private boolean expanded = false;
    private String lastStatus = "Siap. Tekan Analyze untuk membaca layar.";
    private String lastResult = "Belum ada hasil. Analisis dilakukan hanya saat tombol ditekan.";

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private TextRecognizer textRecognizer;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createNotificationChannel();
        captureThread = new HandlerThread("AIControllerCapture");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (mediaProjection != null) {
            return START_NOT_STICKY;
        }

        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            //noinspection deprecation
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }

        if (resultData == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startAsForegroundService();
        startProjection(resultCode, resultData);
        return START_NOT_STICKY;
    }

    private void startAsForegroundService() {
        Intent stopIntent = new Intent(this, AIOverlayService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("AI Controller aktif")
                .setContentText("Screen OCR berjalan di perangkat")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_launcher),
                        "Hentikan", stopPendingIntent).build());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    private void startProjection(int resultCode, Intent resultData) {
        try {
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) {
                showToast("Screen capture gagal dimulai");
                stopSelf();
                return;
            }

            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    showToast("Screen capture dihentikan oleh Android");
                    stopSelf();
                }
            }, mainHandler);

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int width = Math.max(1, metrics.widthPixels);
            int height = Math.max(1, metrics.heightPixels);
            int density = metrics.densityDpi;

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);

            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "AIControllerScreenCapture",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    captureHandler);

            showOverlay();
        } catch (SecurityException exception) {
            showToast("Izin screen capture ditolak atau kedaluwarsa");
            stopSelf();
        } catch (Exception exception) {
            showToast("Gagal memulai AI Controller: " + exception.getClass().getSimpleName());
            stopSelf();
        }
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            showToast("Izin overlay belum aktif");
            stopSelf();
            return;
        }

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        overlayParams = new WindowManager.LayoutParams(
                dp(58), dp(58),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = Math.max(dp(8), metrics.widthPixels - dp(76));
        overlayParams.y = dp(170);

        currentOverlay = makeBubble();
        try {
            windowManager.addView(currentOverlay, overlayParams);
        } catch (Exception exception) {
            showToast("Gagal menampilkan floating overlay");
            stopSelf();
        }
    }

    private View makeBubble() {
        TextView bubble = new TextView(this);
        bubble.setText("AI");
        bubble.setTextSize(19);
        bubble.setTextColor(Color.rgb(5, 24, 20));
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(background(0xFF36D6B0, dp(30)));
        attachDrag(bubble, this::expandPanel);
        return bubble;
    }

    private View makePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(13), dp(12), dp(13), dp(13));
        panel.setBackground(background(0xF0161F2A, dp(18)));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView heading = new TextView(this);
        heading.setText("AI CONTROLLER  •  OFFLINE");
        heading.setTextColor(0xFF36D6B0);
        heading.setTextSize(11);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setLetterSpacing(0.05f);
        header.addView(heading, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView close = smallAction("×", 22, 0xFFFFFFFF);
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> collapsePanel());
        attachDrag(header, null);
        panel.addView(header);

        statusView = new TextView(this);
        statusView.setText(lastStatus);
        statusView.setTextColor(0xFFB7C2CC);
        statusView.setTextSize(12);
        statusView.setPadding(0, dp(8), 0, dp(10));
        panel.addView(statusView);

        analyzeButton = smallAction("ANALYZE SCREEN", 13, 0xFF06130F);
        analyzeButton.setGravity(Gravity.CENTER);
        analyzeButton.setBackground(background(0xFF36D6B0, dp(11)));
        analyzeButton.setPadding(dp(12), dp(11), dp(12), dp(11));
        analyzeButton.setOnClickListener(v -> requestAnalysis());
        panel.addView(analyzeButton, new LinearLayout.LayoutParams(-1, -2));

        TextView resultHeader = new TextView(this);
        resultHeader.setText("HASIL ANALISIS");
        resultHeader.setTextColor(0xFF36D6B0);
        resultHeader.setTextSize(10);
        resultHeader.setTypeface(Typeface.DEFAULT_BOLD);
        resultHeader.setPadding(0, dp(13), 0, dp(6));
        panel.addView(resultHeader);

        ScrollView resultScroll = new ScrollView(this);
        resultScroll.setFillViewport(false);
        resultView = new TextView(this);
        resultView.setText(lastResult);
        resultView.setTextColor(0xFFE7EDF2);
        resultView.setTextSize(12);
        resultView.setLineSpacing(dp(3), 1.0f);
        resultView.setPadding(dp(10), dp(10), dp(10), dp(10));
        resultView.setBackground(background(0xFF0D141D, dp(10)));
        resultScroll.addView(resultView);
        panel.addView(resultScroll, new LinearLayout.LayoutParams(-1, dp(190)));

        TextView footer = new TextView(this);
        footer.setText("Local OCR  •  Tidak mengirim screenshot ke server");
        footer.setTextColor(0xFF71808F);
        footer.setTextSize(9);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(10), 0, 0);
        panel.addView(footer);

        return panel;
    }

    private void requestAnalysis() {
        if (analysisInProgress.get() || pendingAnalysis.get()) {
            setStatus("Analisis sebelumnya masih berjalan. Tunggu sebentar.");
            return;
        }
        pendingAnalysis.set(true);
        setStatus("Menunggu frame layar untuk dianalisis...");
        if (analyzeButton != null) analyzeButton.setText("WAITING...");
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            if (!pendingAnalysis.compareAndSet(true, false)) {
                return;
            }
            analysisInProgress.set(true);
            Bitmap bitmap = imageToBitmap(image);
            image.close();
            image = null;
            if (bitmap == null) {
                analysisInProgress.set(false);
                updateAnalysis("Gagal mengambil gambar layar. Coba lagi.", "Gagal membaca frame.");
                return;
            }
            runOfflineOcr(bitmap);
        } catch (Exception exception) {
            analysisInProgress.set(false);
            updateAnalysis("Terjadi kesalahan saat mengambil gambar: " + exception.getClass().getSimpleName(),
                    "Analisis gagal.");
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) return null;

        Image.Plane plane = planes[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int width = image.getWidth();
        int height = image.getHeight();
        int rowPadding = rowStride - pixelStride * width;
        int paddedWidth = width + Math.max(0, rowPadding / Math.max(1, pixelStride));

        Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        padded.copyPixelsFromBuffer(buffer);

        Bitmap cropped;
        if (paddedWidth == width) {
            cropped = padded;
        } else {
            cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
            padded.recycle();
        }

        // Keep memory use more reasonable on phones with 4 GB RAM.
        int maxDimension = 1500;
        int largest = Math.max(cropped.getWidth(), cropped.getHeight());
        if (largest > maxDimension) {
            float scale = maxDimension / (float) largest;
            int scaledWidth = Math.max(1, Math.round(cropped.getWidth() * scale));
            int scaledHeight = Math.max(1, Math.round(cropped.getHeight() * scale));
            Bitmap scaled = Bitmap.createScaledBitmap(cropped, scaledWidth, scaledHeight, true);
            if (scaled != cropped) cropped.recycle();
            cropped = scaled;
        }
        return cropped;
    }

    private void runOfflineOcr(Bitmap bitmap) {
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            Task<Text> task = textRecognizer.process(image);
            task.addOnSuccessListener(result -> {
                String recognized = result.getText() == null ? "" : result.getText().trim();
                String response = buildLocalAdvice(recognized);
                updateAnalysis(response, "Analisis selesai • diproses di perangkat");
            }).addOnFailureListener(error -> {
                updateAnalysis("OCR gagal membaca gambar. Coba lagi saat teks HUD terlihat jelas.",
                        "OCR gagal: " + error.getClass().getSimpleName());
            }).addOnCompleteListener(done -> {
                if (!bitmap.isRecycled()) bitmap.recycle();
                analysisInProgress.set(false);
                mainHandler.post(() -> {
                    if (analyzeButton != null) analyzeButton.setText("ANALYZE SCREEN");
                });
            });
        } catch (Exception exception) {
            if (!bitmap.isRecycled()) bitmap.recycle();
            analysisInProgress.set(false);
            updateAnalysis("Tidak bisa menjalankan OCR. Silakan coba lagi.", "Analisis gagal.");
        }
    }

    private String buildLocalAdvice(String detectedText) {
        if (detectedText == null || detectedText.trim().isEmpty()) {
            return "Belum ada teks yang terbaca. Pastikan HUD terlihat jelas, tidak tertutup, lalu coba Analyze lagi.\n\n" +
                    "Catatan: v0.1 membaca teks, bukan mendeteksi karakter atau objek.";
        }

        String lower = detectedText.toLowerCase(Locale.ROOT);
        StringBuilder advice = new StringBuilder();
        advice.append("SARAN OFFLINE\n");

        if (lower.contains("safe zone") || lower.contains("zona aman") || lower.contains("zone")) {
            advice.append("• Ada teks yang mungkin berkaitan dengan zona. Periksa indikator zona di game.\n");
        } else if (lower.contains("revive") || lower.contains("resusc") || lower.contains("tolong")) {
            advice.append("• Ada teks yang mungkin berkaitan dengan bantuan atau revive. Periksa status tim di HUD.\n");
        } else if (lower.contains("ammo") || lower.contains("reload") || lower.contains("peluru")) {
            advice.append("• Ada teks yang mungkin berkaitan dengan amunisi. Periksa indikator persediaan di layar.\n");
        } else if (lower.contains("ping") || lower.contains("network") || lower.contains("jaringan")) {
            advice.append("• Ada teks jaringan yang terbaca. Periksa indikator koneksi bila permainan terasa tersendat.\n");
        } else {
            advice.append("• Teks berhasil dibaca, tetapi belum ada pola HUD khusus yang dikenali. Gunakan informasi dalam game sebagai acuan.\n");
        }

        advice.append("\nTEKS YANG TERBACA\n");
        String compact = detectedText.replaceAll("\\n{3,}", "\\n\\n").trim();
        if (compact.length() > MAX_OCR_CHARS) {
            compact = compact.substring(0, MAX_OCR_CHARS) + "…";
        }
        advice.append(compact);
        advice.append("\n\nBatas v0.1: hasil ini hanya OCR + aturan lokal, bukan pemahaman penuh atas adegan game.");
        return advice.toString();
    }

    private void updateAnalysis(String result, String status) {
        lastResult = result;
        lastStatus = status;
        mainHandler.post(() -> {
            if (resultView != null) resultView.setText(result);
            if (statusView != null) statusView.setText(status);
            if (analyzeButton != null) analyzeButton.setText("ANALYZE SCREEN");
        });
    }

    private void setStatus(String value) {
        lastStatus = value;
        if (statusView != null) statusView.setText(value);
    }

    private void expandPanel() {
        if (expanded || overlayParams == null || currentOverlay == null) return;
        View panel = makePanel();
        replaceOverlay(panel, dp(302), dp(390));
        expanded = true;
    }

    private void collapsePanel() {
        if (!expanded || overlayParams == null || currentOverlay == null) return;
        View bubble = makeBubble();
        replaceOverlay(bubble, dp(58), dp(58));
        expanded = false;
    }

    private void replaceOverlay(View newView, int width, int height) {
        try {
            windowManager.removeView(currentOverlay);
        } catch (Exception ignored) {
        }
        overlayParams.width = width;
        overlayParams.height = height;
        currentOverlay = newView;
        try {
            windowManager.addView(currentOverlay, overlayParams);
        } catch (Exception exception) {
            stopSelf();
        }
    }

    private void attachDrag(View view, Runnable onTap) {
        view.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX;
            private float downRawY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View touched, MotionEvent event) {
                if (overlayParams == null || windowManager == null) return false;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = overlayParams.x;
                        startY = overlayParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float deltaX = event.getRawX() - downRawX;
                        float deltaY = event.getRawY() - downRawY;
                        if (Math.abs(deltaX) > dp(5) || Math.abs(deltaY) > dp(5)) moved = true;
                        if (moved) {
                            overlayParams.x = startX + Math.round(deltaX);
                            overlayParams.y = startY + Math.round(deltaY);
                            try {
                                windowManager.updateViewLayout(currentOverlay, overlayParams);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && onTap != null) onTap.run();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private TextView smallAction(String label, int size, int color) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "AI Controller screen capture", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notifikasi saat AI Controller membaca layar");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showToast(String message) {
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show());
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onDestroy() {
        pendingAnalysis.set(false);
        analysisInProgress.set(false);

        if (currentOverlay != null && windowManager != null) {
            try {
                windowManager.removeView(currentOverlay);
            } catch (Exception ignored) {
            }
            currentOverlay = null;
        }

        if (imageReader != null) {
            imageReader.setOnImageAvailableListener(null, null);
            imageReader.close();
            imageReader = null;
        }
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (mediaProjection != null) {
            try {
                mediaProjection.stop();
            } catch (Exception ignored) {
            }
            mediaProjection = null;
        }
        if (textRecognizer != null) {
            textRecognizer.close();
        }
        if (captureThread != null) {
            captureThread.quitSafely();
            captureThread = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
